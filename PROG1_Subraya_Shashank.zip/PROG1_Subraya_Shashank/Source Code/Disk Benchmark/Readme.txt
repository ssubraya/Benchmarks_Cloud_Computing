Disk Benchmark:
This benchmark measures the speed of the disk for the read and write operations. Both sequential and random seeks are implemented for varying concurrency levels[1 thread & 2 thread] and varying block sizes[ 1byte, 1 kilobyte and 1megabite]

Code:
The benchmark has 3 individual file in it. 
�	disk.java: Here the file uses the function run to copy a byte of data into the disk using single thread or 2 threads.
�	diskKB,java: Here the file uses the function run to copy a 1 kilobyte of data into the disk using single thread or 2 threads.
�	disk_megabyte.cpp: Here the file uses the function run to copy a i megabyte of data into the disk using single thread or 2 threads.

Here file handling functions are being performed
�	FileWriter fw=new FileWriter("abc1.txt");
        fw.write("s");  
A simple text file  is created with this function and content 's' is written in it(for 1KB and 1MB we iterate so that the file can have 1KB and 1MB size respectively) .

�	fr.read();
This reads a byte of data from the text file into the buffer.

For the random access a string is 'Hello' is used. The characters from this String are randomly taken and randomly positioned in the file by using.
 Random r=new Random();
 RandomAccessFile file = new RandomAccessFile("abc4.txt", "rw");
 file.seek(v);

File is randomly read using 
 Random r=new Random();
 RandomAccessFile file1 = new RandomAccessFile("abc4.txt", "r");
 file1.seek(v);
 file1.read();


System.nanoTime() function is used to determine the time taken for the transfers, Difference of end time and start time allocated in tot_time_write variable and latency and write speed is calculated in MB/sec accordingly.

The main() function provides the choice to the user for selecting the concurrency. 



Execution:
(For byte)
javac Disk.java
java Disk

***** MENU *****

 1-->Byte Transfer of Single thread 
 2-->Byte Transfer of Two threads   



Select your choice from above menu : 
2

*** Byte Transfer(Two threads) ***

----------Sequential Access ----------------


Latency(time for byte write operation) is   : 1.251025 msec

Throughput(Byte write speed) = 7.623143553536101E-4 MB/s

Latency(time for byte read operation) is   : 0.102199 msec

Throughput(Byte read speed) = 0.00933154254353027 MB/s

* * * * * Random Access * * * * *

Latency(time for byte write operation) is   :  52.826044msec

Throughput(Byte write speed) = 1.8053108735650354E-5MB/s

Latency(time for byte read operation) is  :  0.036751msec

Throughput(Byte read speed) = 0.02594961542287965MB/s


Do you wish to continue...??? 
1 --> YES
2 --> NO


(For KB)
javac DiskKB.java
java DiskKB



 ***** MENU *****

 1-->Byte Transfer of Single thread 
 2-->Byte Transfer of Two threads   



Select your choice from above menu : 
2

*** Byte Transfer(Two threads) ***

----------Sequential Access ----------------

Latency(time for kilobyte write operation) is   : 0.0467497763671875 msec

Throughput(KiloByte write speed) = 20.889137358214718 MB/s

Latency(time for kilobyte read operation) is   : 0.027861400390625 msec

Throughput(KiloByte read speed) = 35.05073278113474 MB/s

* * * * * Random Access * * * * *

Latency(time for kilobyte write operation) is   :  0.0274964033203125msec

Throughput(KiloByte write speed) = 35.516008716622984MB/s

Latency(time for kilobyte read operation) is  :  0.001817998046875msec

Throughput(KiloByte read speed) = 537.1636683981243MB/s


Do you wish to continue...??? 
1 --> YES
2 --> NO


(For MB)
javac DiskMB.java
java DiskMB



***** MENU *****

 1-->Byte Transfer of Single thread 
 2-->Byte Transfer of Two threads   



Select your choice from above menu : 
2

*** Byte Transfer(Two threads) ***

----------Sequential Access ----------------


Latency(time for megabyte write operation) is   : 4.7811726284027105E-4 msec

Throughput(MegaByte write speed) = 2091537.1138441388 MB/s

Latency(time for megabyte read operation) is   : 3.9789929676055906E-4 msec

Throughput(MegaByte read speed) = 2513198.711687502 MB/s

* * * * * Random Access * * * * *

Latency(time for megabyte write operation) is   :  0.002831602764129639msec

Throughput(MegaByte write speed) = 353156.88085485186MB/s

Latency(time for megabyte read operation) is  :  0.0013151202411651613msec

Throughput(MegaByte read speed) = 760386.7454081817MB/s


Do you wish to continue...??? 
1 --> YES
2 --> NO
